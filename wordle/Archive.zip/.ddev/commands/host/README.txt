#ddev-generated
Scripts in this directory will be executed on the host
but they can take easily take action on containers by using
`ddev exec`.

See https://ddev.readthedocs.io/en/stable/users/extend/custom-commands/#environment-variables-provided for a list of environment variables that can be used in the scripts.
