# Introduction



<aside>
    <strong>Base URL</strong>: <code>https://wordle.ddev.site</code>
</aside>

This documentation aims to provide all the information you need to work with our API.

